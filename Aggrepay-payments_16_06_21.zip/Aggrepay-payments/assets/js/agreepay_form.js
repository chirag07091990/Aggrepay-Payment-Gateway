
jQuery("form[name='agree_pay_form']").validate({

  rules: {

     "name": "required",
     "email": "required",
     "mobile" : { required: true,number: true,minlength:10},       
     "address": "required", 
     "country": "required",   
     "city": "required",
     "state": "required", 
     "zipcode":  { required: true,number: true,minlength:4,maxlength:6},   
     "amount":  { required: true,number: true}   
  },

 messages: {
   "name": "Please Enter Name",
   "email": "Please Enter Email Address",
   "mobile" : {required: "Please Enter Mobile Number",minlength:"Please Enter Minimum 10 digit Number"},
   "address": "Please Enter Address",     
    "city": "Please Select City",
   "state": "Please Select State",
   "country": "Please Select Country",
   "zipcode": {required: "Please Enter zip code"},
   "amount": {required: "Please Enter Amount"}
},

submitHandler: function(form) {

      jQuery('.fa-spin').show();

     // jQuery(form).submit();

      form.submit();

      return false;       

 }

});	
jQuery(document).on("change",'#agreepay_country',function(event){
          //event.preventDefault();
          //alert(jQuery(this).val());
          

          var $inputs = jQuery(jQuery(this).attr('data-state'));

          // Let's disable the inputs for the duration of the Ajax request.
          // Note: we disable elements AFTER the form data has been serialized.
          // Disabled form elements will not be serialized.
          $inputs.prop("disabled", true);

          // Fire off the request to /form.php
          request = jQuery.ajax({
              url: agreepay_parameter.ajax_state_url,
              dataType: 'JSON',
              type: "post",
              data: {'country':jQuery(this).val()}
          });

          // Callback handler that will be called on success
          request.done(function (response, textStatus, jqXHR){              
              if(response.status == 'OK'){
                  $inputs.html(response.result);                  
              }else{
                console.log(response.result);
              }
          });

          // Callback handler that will be called on failure
          request.fail(function (jqXHR, textStatus, errorThrown){
              // Log the error to the console
              console.error(
                  "The following error occurred: "+
                  textStatus, errorThrown
              );
          });

          // Callback handler that will be called regardless
          // if the request failed or succeeded
          request.always(function () {
              // Reenable the inputs
              $inputs.prop("disabled", false);
          });
          event.preventDefault();
});