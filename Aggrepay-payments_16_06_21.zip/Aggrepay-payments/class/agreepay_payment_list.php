<?php
if(!class_exists('AgreePay')){
	Class AgreePay{
		function __construct(){
			add_action( 'admin_menu', array($this,'register_my_custom_menu_page') );
		}
		function register_my_custom_menu_page() {
		  // add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
		  add_menu_page( 'AgreePay Payment Gateway', 'AgreePay Payment', 'manage_options', 'agreepay_payment',array($this,'agreepay_payment_list'), 'dashicons-shield', 90 );
		}
		public function agreepay_payment_list(){
			echo "hii";
		} 
		
	}
	New AgreePay();	
}
?>