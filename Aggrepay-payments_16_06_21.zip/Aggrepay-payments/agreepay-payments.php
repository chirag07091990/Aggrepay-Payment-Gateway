<?php
/*
Plugin Name: AgreePay Payment Gateway
Plugin URI: https://www.webplusinfotech.net/
description: Customize Plugin for AgreePay Payment Gateway
Version: 1.1
Author: Mr. Chirag Rana
Author URI: http://mrtotallyawesome.com
License: https://www.webplusinfotech.net/
*/
define('AGREEPAY_URL',plugin_dir_url(__FILE__));
define('AGREEPAY_NAME','agreepay');
define('AGREEPAY_JSON',plugin_dir_url(__FILE__)."josn/");
define('AGREEPAY_ASSETS',plugin_dir_url(__FILE__)."assets/");
define('AGREEPAY_ASSETS_CSS',plugin_dir_url(__FILE__)."assets/css/");
define('AGREEPAY_ASSETS_JS',plugin_dir_url(__FILE__)."assets/js/");
define('AGREEPAY_PATH',plugin_dir_path(__FILE__));
define('AGREEPAY_FORM_KEY','GkzcNt4ZREwQTinHgOlU');
define('AGREEPAY_FORM_KEY_NAME','agReepayToken');

include(AGREEPAY_PATH."json/countries.php");
include(AGREEPAY_PATH."class/agreepay_payment_table.php");
include(AGREEPAY_PATH."class/agreepay_payment_list.php");
include(AGREEPAY_PATH."class/agreepay_payment_setting.php");
include(AGREEPAY_PATH."class/agreepay_payment_form.php");


register_activation_hook( __FILE__, array('AgreePayTable','roytuts_on_activation') );
//register_activation_hook( __FILE__, array('AgreePayTable','agreepay_install_data') );


?>