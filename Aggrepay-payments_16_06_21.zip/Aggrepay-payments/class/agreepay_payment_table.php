<?php
if(!class_exists('AgreePayTable')){
	Class AgreePayTable{
		private $table;
		function __construct(){
			
		}	
		function roytuts_on_activation(){
			// create the custom table
			global $wpdb;
			
			$table_name = $wpdb->prefix . 'agreepay_payment_gateway';
			$charset_collate = $wpdb->get_charset_collate();
			
			$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		        id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		        name varchar(100) NOT NULL,
		        mobile int(10) NOT NULL,
		        email int(10) NOT NULL,
		        address longtext NOT NULL,	
		        country varchar(50) NOT NULL,
		        state varchar(50) NOT NULL,
		        city varchar(50) NOT NULL,
		        zipcode int(10) NOT NULL,
		        amount int(10) NOT NULL,
		        currency varchar(5) NOT NULL,
		        hash longtext NOT NULL,
		        pay_status varchar(15) NOT NULL,		        
		    	pay_id varchar(50) NOT NULL default '') $charset_collate;";
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}
		public function agreepay_install_data(){
				global $wpdb;	
				$table_name = $wpdb->prefix . 'agreepay_payment_gateway';	
				$wpdb->insert( 
					$table_name, 
					array( 
						'id'=>1,
						'name' => 'chirag', 
						'mobile' => '8866714973', 
						'email' => 'chiragr001@gmail.com',
						'address'=>'d-142,shaktitenament,nr.h=shantibag society,isanpur,ahmdabad.',
						'country'=>'india',
						'state'=>'gujarat',
						'city'=>'ahmedabad',
						'zipcode'=>'382443',
						'amount'=>'100',
						'currency'=>'INR',
						'hash'=>'dfnsdkfkhksfhksdfhskfhshfskfhsfhskfjkfhdkfl',
						'pay_status'=>'complete',
						'pay_id'=>'12345679'
					) 
				);
		}
	}
}
?>