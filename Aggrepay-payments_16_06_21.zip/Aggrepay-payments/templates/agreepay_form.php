<?php
/*
 * Template Name: Good to Be Bad
 * Description: A Page Template with a darker design.
 */
get_header();
breadcrumbs();
$load = get_option( 'agreepay_payment_setting' );
?>  
<style>
.agreepay h2 {
 
    font-size: 25px;
    color: #C50340;
    text-align: center;
    padding: 19px 0;
    line-height: 40px;
}
.agreepay span.error {
    color: red;
    font-size: 12px;
}
</style>
<div class="container">
        <div class="row justify-content-md-center">
        <div class="agreepay col-8">
        <?php echo (isset($load['customform_before_header_note']) ? apply_filters('the_content',$load['customform_before_header_note']) : ""); ?>
        <form name="agree_pay_form"  role="form" name="paynow" action="<?php echo admin_url( 'admin-post.php' );?>" method="post" style="margin: 32px auto;"> 
           <?php wp_nonce_field((isset($load['form_key']) ? $load['form_key'] : AGREEPAY_FORM_KEY) , AGREEPAY_FORM_KEY_NAME ); ?> 
             <input type="hidden" action="agreepay_form">
            <div class="form-row my-3">
                <div class="col">
                <label for="inputEmail3" class="control-label">First Name </label>
                    <input type="text" value="" name="name" class="form-control">
                <label for="name" generated="true" class="error" style="display: none;"></label>    
                </div>
            </div>
            <div class="form-row my-3">
                <div class="col">
                         <label for="inputEmail3" class="control-label">Email </label>
                    <input type="email" value="" name="email" class="form-control"> 
                    <label for="email" generated="true" class="error" style="display: none;"></label>    
                </div>
                <div class="col">
                    <label for="inputEmail3" class="control-label">Mobile No </label>
                    <input type="number" value="" minlength="10"  name="mobile" class="form-control">
                </div>
            </div>            
            <div class="form-row my-3">
                <div class="col">
                      <label for="inputEmail3" class="control-label">Address </label>
                    <input type="text" value="" name="address" class="form-control">   
                    <label for="address" generated="true" class="error" style="display: none;"></label>       
                </div>                
            </div>
            <div class="form-row my-3">
            <?php if( isset($load['currency']) && strcasecmp($load['currency'],'INR') == 0){  ?>
            
                <div class="col">
                    <label for="inputEmail3" class="control-label">Country </label>
                    <select name="country" data-state="#agreepay_state" id="agreepay_country"  class="form-control">
                        <?php echo select_country("Select Country."); ?>
                    </select>                    
                    <label for="country" generated="true" class="error" style="display: none;"></label>    
                </div>
                <div class="col">
                    <label for="inputEmail3" class="control-label">State </label>
                    <select name="state" id="agreepay_state"  class="form-control">
                        <option>Select State</option>

                    </select> 
                </div>
                <div class="col">
                    <label for="inputEmail3" class="control-label">City </label>
                    <input type="text" value="" name="city" class="form-control">
                </div>
            <?php }else{ ?>
               
                <div class="col">
                    <label for="inputEmail3" class="control-label">Country </label>
                    <input type="text" value="" name="country" class="form-control">
                </div>
                <div class="col">
                    <label for="inputEmail3" class="control-label">State </label>
                    <input type="text" value="" name="state" class="form-control">
                    <label for="state" generated="true" class="error" style="display: none;"></label>    
                </div>
                <div class="col">
                    <label for="inputEmail3" class="control-label">City </label>
                    <input type="text" value="" name="city" class="form-control">
                    <label for="city" generated="true" class="error" style="display: none;"></label>    
                </div>     
               <?php } ?> 
               <div class="col">
                    <label for="inputEmail3" class="control-label">Zipcode </label>
                    <input type="number" minlength="4" maxlength="6" value="" name="zipcode" class="form-control">
                    <label for="zipcode" generated="true" class="error" style="display: none;"></label>    
                </div> 
            </div>
            <div class="form-row my-3">
                
                <div class="col">
                <label for="inputEmail3" class="control-label">Amount<?php echo (isset($load['currency']) ? " ( ".$load['currency']." ) " : "");?> </label>
                <input type="text" value="" name="amount" class="form-control">
                <label for="amount" generated="true" class="error" style="display: none;"></label>    
                </div>
            </div>  
            <div class="form-row my-3">
                <div class="col">
                    <input  type="submit" value="Pay Now" name="subscribe" id="mc-embedded-subscribe" class="btn btn-danger">                
                </div>
                <div class="col">
                    <div class="payment-icon">
                        <ul class="d-flex justify-content-end">
                            <li class="p-2"><i class="fa fa-credit-card" aria-hidden="true"></i></li>
                            <li class="p-2"><i class="fa fa-cc-visa" aria-hidden="true"></i></li>
                            <li class="p-2"><i class="fa fa-desktop" aria-hidden="true"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
        </form> 
        <div class="content-end">
        <?php echo (isset($load['customform_after_header_note']) ? apply_filters('the_content',$load['customform_after_header_note']) : ""); ?>
        </div>
    </div>
    </div>
    </div>
<?php
get_footer();