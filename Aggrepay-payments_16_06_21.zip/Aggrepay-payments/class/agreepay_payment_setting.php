<?php
if(!class_exists('AgreePay_settings')){
Class AgreePay_settings{

	public function __construct(){
		add_action( 'admin_menu', array($this, 'register_sub_menu') );
		add_action( 'admin_init', array( $this, 'page_init' ) );
	}
	public function register_sub_menu() {	  
	  	add_submenu_page( 'agreepay_payment', 'Settings', 'Settings',
    	'manage_options','agreepay-payment-option-admin',array($this,'agreepay_payment_option'));
	}	
	public function agreepay_payment_option(){
		$this->options = get_option( 'agreepay_payment_setting' );
        ?>
        <div class="wrap">
            <!-- <h1>My Settings</h1> -->
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'agreepay_payment_option_group' );
                do_settings_sections( 'agreepay-payment-option-admin' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
	}  
	public function page_init(){
		register_setting(
            'agreepay_payment_option_group', // Option group
            'agreepay_payment_setting', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', // ID
            'AgreePay Payment Settings', // Title
            array( $this, 'print_section_info' ), // Callback
            'agreepay-payment-option-admin' // Page
        );  

        add_settings_field(
            'api_key', // ID
            'API Key', // API 
            array( $this, 'api_key_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );      

		add_settings_field(
            'salt', // ID
            'Salt Key', // Salt 
            array( $this, 'salt_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        ); 
        add_settings_field(
            'mode', // ID
            'Payment Mode', // mode 
            array( $this, 'mode_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );        
        add_settings_field(
            'currency', // ID
            'Currency Codes', // currency 
            array( $this, 'currency_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );
        add_settings_field(
            'customform', // ID
            'Payment Mode', // mode 
            array( $this, 'customform_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );
        add_settings_field(
            'form_key', // ID
            'Form Key', // Form Key 
            array( $this, 'form_key_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );
        add_settings_field(
            'customform_before_header_note', // ID
            'Before Form Header', // mode 
            array( $this, 'customform_header_note_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );
        add_settings_field(
            'customform_after_header_note', // ID
            'After Form Header', // mode 
            array( $this, 'customform_after_header_note_callback' ), // Callback
            'agreepay-payment-option-admin', // Page
            'setting_section_id' // Section           
        );
        //

	}
    function customform_header_note_callback(){

    $content   = isset( $this->options['customform_before_header_note'] ) ? ( $this->options['customform_before_header_note']) : "AgreePay Payment gateway <br><br> Pay Now With Credit Card , Debit Card &amp; Net banking.";            
    $editor_id = 'customform_before_header_note';
    $settings  = array( 'media_buttons' => false,'textarea_name'=>'agreepay_payment_setting[customform_before_header_note]','editor_height'=>'200');
    wp_editor( $content, $editor_id,$settings);            
    }
    function bc_get_wp_editor( $content = '', $editor_id, $options = array() ) {
        ob_start();
     
        wp_editor( $content, $editor_id, $options );
     
        $temp = ob_get_clean();
        $temp .= \_WP_Editors::enqueue_scripts();
        $temp .= print_footer_scripts();
        $temp .= \_WP_Editors::editor_js();
     
        return $temp;
    }
    function customform_after_header_note_callback(){

    $content   = isset( $this->options['customform_after_header_note'] ) ? ( $this->options['customform_after_header_note']) : "";
    $editor_id = 'customform_after_header_note';
    $settings  = array( 'media_buttons' => false,'default_editor'=>true,'textarea_name'=>'agreepay_payment_setting[customform_after_header_note]','editor_height'=>'200');
    wp_editor( $content, $editor_id,$settings);            
    }
	function my_settings_sanitize( $input ){
	    return isset( $input ) ? true : false;
	}
	 /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'Kindly Configure Your settings below:';
    }

    /** 
     * Get the settings option array and print one of its values
     */
     public function api_key_callback()
    {
        printf(
            '<input required type="text" id="api_key"  name="agreepay_payment_setting[api_key]" value="%s" style="%s"/>',
            isset( $this->options['api_key'] ) ? esc_attr( $this->options['api_key']) : '',
            'width:100%;display:block;'
        );
    }
    /*form Key*/
    public function form_key_callback(){
        printf(
            '<input required type="text" id="form_key"  name="agreepay_payment_setting[form_key]" value="%s" style="%s"/>',
            isset( $this->options['form_key'] ) ? esc_attr( $this->options['form_key']) : md5(rand()),
            'width:100%;display:block;'
        );   
    }
    /*Salt Key*/
    public function salt_callback()
    {
        printf(
            '<input required type="text" id="salt"  name="agreepay_payment_setting[salt]" value="%s" style="%s"/>',
            isset( $this->options['salt'] ) ? esc_attr( $this->options['salt']) : '',
            'width:100%;display:block;'
        );
    }
    /* Mode For Test/ Live Mode*/
    public function mode_callback()
    {
	?>
    <select required name="agreepay_payment_setting[mode]" style="max-width: 100%;width:100%;display:block;">
    	<option value="" <?php selected(
            isset( $this->options['mode'] ) ? esc_attr( $this->options['mode']) : '',''); ?>>Select Mode</option>
          <option value="test" <?php selected(
            isset( $this->options['mode'] ) ? esc_attr( $this->options['mode']) : '','test'); ?>>Test</option>
          <option value="live" <?php selected(
            isset( $this->options['mode'] ) ? esc_attr( $this->options['mode']) : '','live'); ?>>Live</option>
        </select>

        <?php
        
    }
    public function currency_callback()
    {

    $currency = array(
    			array("INR"=>'Indian Rupee'),
    			array("USD"=>'United States Dollar'),
    			array("EUR"=>'Euro'),
    			array("SGD"=>'Singapore Dollar'),
    			array("HKD"=>'Hong Kong Dollar'),
    			array("GBP"=>'British Pound'),
    			array("AUD"=>'Australian Dollar'),
    			array("AED"=>'Arab Emirates Dinar'),
    		);	
	?>

    <select required name="agreepay_payment_setting[currency]"  style="max-width: 100%;width:100%;display:block;">
    	<option value="" <?php selected(
            isset( $this->options['currency'] ) ? esc_attr( $this->options['currency']) : '',''); ?>>Select Currency</option>
            <?php
            	if(!empty($currency) && is_array($currency)){
            		foreach($currency as $keys=>$vals){
            			foreach($vals as $key=>$val){            			
            			printf('<option value="%1$s" %2$s>%3$s ( %1$s )</option>',$key,selected(
            			isset( $this->options['currency'] ) ? esc_attr( $this->options['currency']) : '',$key,false),$val);          		
            			}
            		}
            }
            ?>
        </select>

        <?php
        
    }
    public function customform_callback(){
    	echo 'Form You can Call By ShortCode <strong>[agreepay_form]</strong> Or in Custom Theme you can call via action <strong>do_action("agreepay_form")</strong>';
    }

}
New AgreePay_settings();	
}

?>