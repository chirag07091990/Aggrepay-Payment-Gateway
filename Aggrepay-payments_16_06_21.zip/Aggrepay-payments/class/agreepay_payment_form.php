<?php
if(!class_exists('AgreePay_Form')){
	Class AgreePay_Form{
		public function __construct(){
			add_shortcode('agreepay_form',array($this,'agreepay_form'));
			add_filter('theme_page_templates', array($this,'pt_add_page_template_to_dropdown'));
			add_filter('template_include', array($this,'pt_change_page_template'), 99);
				
			add_filter('page_template', array($this,'catch_plugin_template'));
			add_action( 'wp_enqueue_scripts', array($this,'mytheme_enqueue_style') );
			add_action( 'wp_ajax_agreepay_state', array($this,'agreepay_state') );
			add_action( 'wp_ajax_nopriv_agreepay_state', array($this,'agreepay_state') );
			
		}
		
		public function catch_plugin_template($template){
			
					
			// If tp-file.php is the set template
		    if( is_page_template('agreepay_form.php') )
		    		
		        // Update path(must be path, use WP_PLUGIN_DIR and not WP_PLUGIN_URL) 
		     $template = AGREEPAY_PATH . 'templates/agreepay_form.php';
		 	
		    // Return
		    return $template;
		}
		public function agreepay_form(){

		}
		/**
		 * Add page templates.
		 *
		 * @param  array  $templates  The list of page templates
		 *
		 * @return array  $templates  The modified list of page templates
		 */
		public function pt_add_page_template_to_dropdown($templates)
		{
		    $templates['agreepay_form.php'] = __('Agreepay Form');
		 
		    return $templates;
		}
		 
		/**
		 * Change the page template to the selected template on the dropdown
		 * 
		 * @param $template
		 *
		 * @return mixed
		 */

		public function pt_change_page_template($template)
		{
				
		    if (is_page() && !is_home() && !is_front_page()) {
		    	if(strcasecmp('agreepay_form.php',$template) == 0){
			    	$template = AGREEPAY_PATH . 'templates/agreepay_form.php';
			    	
			    }

		    }
		    

		    return $template;
		}
		public function mytheme_enqueue_style() {
		    wp_enqueue_script( AGREEPAY_NAME.'-validate', AGREEPAY_ASSETS_JS."jquery.validate.js",array(),'jQuery', true ); 
		    wp_enqueue_script( AGREEPAY_NAME.'-validate-form', AGREEPAY_ASSETS_JS."agreepay_form.js",array(),array('jQuery',AGREEPAY_NAME.'-validate'), true ); 
		    wp_localize_script( AGREEPAY_NAME.'-validate-form', 'agreepay_parameter', array(
			    'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			    'ajax_state_url' => admin_url( 'admin-ajax.php' )."?action=agreepay_state",
			) );
		}
		public function agreepay_state(){
				if(isset($_POST['country']) && !empty($_POST['country'])){
						$get_state = get_state_select_by_code($_POST['country'],"Select State");
						if(!empty($get_state)){
							$data['status'] = 'OK';
							$data['result'] = $get_state;
						}else{
							$data['status'] = 'ERROR';
							$data['result'] = 'States Did Not Found.';
						}
				}else{
					$data['status'] = 'ERROR';
					$data['result'] = 'No Naughty Business Please.';
				}
				echo json_encode($data);
				exit;
		}		

	}
	new AgreePay_Form();
}
?>