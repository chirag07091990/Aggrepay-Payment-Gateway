<?php
if(!class_exists('AgreePayTableJson')){
	Class AgreePayTableJson{
		private $table;
		function __construct(){
			
		}		
		public function get_country(){			
			$globals;

			
			
			/*$responseBody = wp_remote_retrieve_body( $response );
			$result = json_decode( $responseBody );
			if ( is_array( $result ) && ! is_wp_error( $result ) ) {
			  	print("<pre>");print_r($result);
			} */
		}
		function connect($country_file){
		    $ch = curl_init();
		    $headers = array(
		    'Accept: application/json',
		    'Content-Type: application/json',

		    );
		    curl_setopt($ch, CURLOPT_URL, $country_file);
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		    curl_setopt($ch, CURLOPT_HEADER, 0);
		    $body = '{}';

		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET"); 
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$body);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		    // Timeout in seconds
		    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

		    $authToken = curl_exec($ch);

		    return $authToken;
		}
	}
	$json_file = new AgreePayTableJson();
	$json_file->get_country();
}